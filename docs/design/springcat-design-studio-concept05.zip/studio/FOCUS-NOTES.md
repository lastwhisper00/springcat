# Concept 05 · Focus

## Scope and authority

This is a scoped redesign of the existing expanded panel, its actions and its task list. It preserves the user-confirmed professional desktop direction, the three neutral themes, the SpringCat name, small resting forms, top/notch/side positioning, and the 520px expanded width. It does not establish a new product or brand identity. The production Svelte/Tauri implementation is outside this design-prototype change.

## Reading and action order

1. Identify the state that needs attention: “待你确认 · 1 项”.
2. Read the source, task name and one sentence explaining the pending action.
3. Follow the single leading action, “查看请求”. This opens the existing example task detail; actual authorization remains in the source tool.
4. Scan the other tasks using consistent source logos, two-line text and quiet status labels.
5. Open the full workspace for the complete task list and longer work.

The default state is an illustrative waiting task, not live user data. Running, completed, failed, focus and idle examples continue to work, with different overview wording and matching secondary task states.

## Visual decisions

- Brand and three navigation choices share one quiet header row.
- Overview 20px; leading task 18px/600; secondary titles 14px; source, time and navigation 12px.
- The primary action uses 13px text and a small vector arrow, with no solid blue block. Desktop hit height is at least 32px; coarse pointers receive larger targets.
- Tighter spacing within a task, greater spacing between the leading task and the secondary group. Only group boundaries use a hairline.
- Source logos are reused from `src/assets/tool-logos`; letter tiles are removed.
- No fixed minimum content height and no nested scrolling. Text may wrap and detail remains available.
- The new stylesheet replaces the older layered overrides. No new UI framework or runtime dependency is added.

## Skill evidence and judgment

Impeccable context was run once. It reported an incumbent implementation and allowed scoped refinement without a new product/brand interview. Operate, Layout, Distill and Craft Floor were read; an independent layout assessment informed the work.

UI UX Pro Max identified the relevant professional-tool/minimalist family. Its FAQ landing pattern, scroll-reveal preset and coding-font recommendation were not applied to this compact desktop surface. Button/list searches did not return a verified exact match after the bounded retry; those choices use Impeccable's Operate/Distill rules and the user's explicit feedback. Text reflow and spacing guidance was applicable.

Karpathy Guidelines kept this change limited to the design artifact, removed obsolete prototype CSS and listeners, and required observable checks for content visibility and interaction results.

## Integration limits

These are design prototypes. Real native-window motion, screen-edge constraints, safe areas and cross-tool deep links still require verification when implemented in Tauri. SVG artboards are static, while the prototype provides the interaction examples.

## Review record

The required mechanical detector was run once after the initial implementation. It found contrast and small-label warnings in the preview chrome and illustrative desktop, plus a width/height transition warning. Functional preview labels were darkened and raised to at least 11px, and colored shadows were changed to neutral elevation shadows. The low-contrast editor backdrop is intentionally decorative and `aria-hidden`; it carries no task or control information.

The shape transition warning is a deliberate prototype exception: the floating shell morphs width/height while text remains at its final size. This is not a claim of native compositor performance. Reduced-motion mode disables this spatial transition. Initial rendering and theme changes no longer animate through clipped or low-contrast intermediate states.

The first combined visual/interaction pass found transient auto-scroll during detail-to-list return. The shell now uses non-scrolling clipping and explicitly returns keyboard focus to the originating task. The secondary list no longer extends its hit boxes outside the content width.

The confirmation pass verified 520px desktop width, five dock positions remaining inside the scene, and zero content overflow for task/action/recap views at narrow width. Failed task detail returns focus to the originating task, with shell scrollTop remaining zero. Functional palette contrast checks found a minimum 4.75:1 across the three themes. Source SVGs are bundled in `assets/tool-logos` so the exported package can be regenerated without accessing the original repository.
