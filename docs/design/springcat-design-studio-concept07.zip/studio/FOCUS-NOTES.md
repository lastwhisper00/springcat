# Concept 07 · Activity

## Scope and authority

The user requested removal of the repeated SpringCat label in the expanded floating header and restoration of an illuminated ball that indicates active execution. This scoped change preserves the uniform task rows established in Concept 06, the three neutral themes, small resting forms, docking positions, and 520px expanded width. Branding remains available in the independent workspace and design-review shell. Production Svelte/Tauri code is outside this design-prototype change.

## Execution indicator contract

- Replace the floating header brand with a 14px ball and quiet 12px “N 项进行中” text.
- Count running tasks across the entire task collection, including tasks on other pages. Pagination never changes the aggregate indicator.
- One or more running tasks lights the ball with a soft, steady blue glow. No running tasks produces a neutral dark ball and “暂无进行中”.
- Waiting for confirmation, completion, and failure do not light the execution ball. They retain their ordinary row states.
- Resting top capsules, side balls, summary capsules, and the notch edge use the same execution semantics. Footer green remains a separate connection indicator.
- Running row dots are slightly brighter while retaining the “进行中” label and ordinary row geometry.
- No breathing or blinking animation is introduced. Reduced-motion mode retains the static illuminated state.
- Prototype scenarios include waiting-only tasks with zero execution and all tasks completed, so absence of execution can be inspected directly.

## Task list contract

1. Use the neutral heading “最近任务” and a quiet total count.
2. Every task has the same source-logo position, title size and weight, source/time line, row height, and background. The right edge shows a 12px state label and a 4px colored dot.
3. “待确认”, “进行中”, “已完成” and “失败” are peer statuses. Pending confirmation never creates a larger card, banner or separate action area.
4. Each pending task occupies one row. The default five-task example contains three waiting tasks interleaved with a running task and a completed task.
5. Sort by recent update when opening or refreshing. While reading, update a task in place and preserve its position, current page, and focused element.
6. Show at most five tasks per page, with explicit previous/next controls and total/range when more exist. Reducing page size on low-height native screens is an integration requirement, not behavior already implemented by this browser prototype. “全部任务” opens the full workspace.
7. Clicking a row opens that task’s existing detail. Request explanation and source actions belong in this detail. Reading or marking a task as read does not resolve a waiting status.

## Visual decisions

- The execution ball and count share a quiet header row with the three navigation choices. The floating header no longer repeats the brand name.
- The list heading uses quiet 13px / 500 text and all task titles use 14px / 450; source, time, count, and state use 12px / 400. Detail titles use 20px / 550.
- All task rows are 64px high; longer content and narrow layouts must preserve readable text and accessible detail access.
- Row status text uses the same quiet text color; only the small state indicator varies by status.
- There are no per-row action buttons, nested cards, strong separators, or special completed-title dimming.
- “标记已读” remains a secondary text control. Source logos and existing lightweight SVG action icons are reused.
- Unpaginated panels follow their content height (470px for five tasks). Paginated lists preserve a 320px minimum list height, keeping both pages at 506px total height. There is no nested scrolling. Existing themes and motion rules remain unchanged.

## Skill application

Impeccable's Operate and Craft Floor rules support consistent controls, quiet semantic color, and predictable scanning. The existing design context permits scoped refinement without a new product interview. Karpathy Guidelines keep the change limited to the task list, its data examples, and the corresponding design artifacts. No new framework or runtime dependency is required.

## Verification record for this revision

The mixed five-task example displays “1 项进行中”; the running example displays two. Waiting-only and all-completed examples display a dark ball. Both pages of the eight-task example retain the full total of two running tasks while each page shows one running row. The graphite desktop and mist 390px viewport were inspected; the 323px panel has zero header or list overflow. Reduced motion retains a static 14px lit header ball. The side resting form uses a 14px ball, and the notch edge uses a visible 4px indicator. No browser console errors were recorded.

The detector ran once. Its glow finding is intentionally retained for the user's explicit execution-light brief; it is a bounded, nonanimated status signal. Existing illustrative backdrop and shell layout-transition findings remain unchanged. All 288 SVGs and three JSON files parsed; the prototype, generator and two viewer JavaScript sources passed syntax checks. Concept 06 list behavior checks remain the baseline for unchanged task selection, read state and return focus.

## Integration limits

These are design prototypes. Real native-window motion, screen-edge constraints, safe areas, reduced-height page sizing, and cross-tool deep links require verification in Tauri. SVG artboards show static states; the prototype provides interaction examples. Reading a preview never grants approval to a source tool.
