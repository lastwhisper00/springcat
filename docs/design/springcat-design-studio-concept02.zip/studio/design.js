(() => {
  'use strict';
  const data=window.SPRINGCAT_DESIGN;
  const $=s=>document.querySelector(s);
  let page='placement',theme='graphite',selected=null;
  const names={graphite:'石墨黑',porcelain:'雾白',companion:'暖白猫咪'};
  const notes={placement:'主方案：顶部小胶囊 / 刘海融合。侧边小球为备选。所有画板展示重设计目标，并非已集成的系统截图。',states:'图中以“待处理优先”设计。当前版本为“运行优先”；新的专注策略也属于拟改版。',workspace:'现有任务监听保留；详情、历史筛选和跳转失败反馈属于设计补齐。未来动作入口独立标注。',settings:'保留现有设置和 8 个来源接入。主题、减少动态效果与保存失败反馈属于新增设计。',onboarding:'首次使用向导是新增设计。允许跳过，并在设置中随时连接工具或调整位置。',usage:'图中所有用量都是示例。API 等价估算不代表订阅账单；各来源的数据覆盖不同。',style:'三个主题复用同一套形态与尺寸。导出的 SVG 保留文字和矢量图形，暖白猫咪属于未来外观。',flows:'这些流程定义产品应如何响应用户。已存在的能力与新的交互策略分别标记。'};
  const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const tagClass=a=>a.availability.includes('未来')?'future':a.availability.includes('提案')||a.availability.includes('补齐')?'proposed':'';
  function meta(a){return `<span class="badge ${tagClass(a)}">${escape(a.availability)}</span>`;}
  function annotations(a){return `<div class="notes"><div class="selected-id">${escape(a.id)}</div><h2>${escape(a.title)}</h2>${meta(a)}<dl><dt>触发 / 入口</dt><dd>${escape(a.entry)}</dd><dt>主要交互</dt><dd>${escape(a.action)}</dd><dt>收起 / 返回</dt><dd>${escape(a.exit)}</dd><dt>产品约束</dt><dd>${escape(a.note)}</dd></dl></div>`;}
  function downloadLink(a){return `artboards/${a.id}-${theme}.svg`;}
  function select(id,open=false){
    selected=data.boards.find(a=>a.id===id);if(!selected)return;
    document.querySelectorAll('.frame-button').forEach(el=>el.classList.toggle('selected',el.dataset.id===id));
    $('#inspector').innerHTML=annotations(selected)+`<div class="size"><span>W ${selected.width}</span><span>H ${selected.height}</span></div><button class="inspect-open">放大查看 ↗</button><a class="inspect-download" href="${downloadLink(selected)}" download>下载 ${names[theme]} SVG ↓</a><hr><div class="note-small">画板尺寸是设计展示尺寸。组件逻辑尺寸见画板内标注与视觉规范。<br>所有动作与数据为演示，未修改真实应用设置。</div>`;
    $('.inspect-open').addEventListener('click',openDetail);
    if(open)openDetail();
  }
  function openDetail(){if(!selected)return;$('#detail-id').textContent=selected.id+' · '+names[theme];$('#detail-title').textContent=selected.title;$('#stage').innerHTML=selected.svgs[theme];$('#detail-notes').innerHTML=annotations(selected);$('#download-svg').href=downloadLink(selected);$('#download-svg').download=`${selected.id}-${theme}.svg`;if(!$('#detail').open)$('#detail').showModal();requestAnimationFrame(scaleDetail);}
  function scaleDetail(){const svg=$('#stage svg');if(!svg||!selected)return;let scale=$('#detail-scale').value;if(scale==='fit')scale=Math.min(1,($('#stage').clientWidth-48)/selected.width,matchMedia('(min-width:701px)').matches?($('#stage').clientHeight-48)/selected.height:1);else scale=Number(scale);scale=Math.max(.2,Number(scale));svg.style.width=`${selected.width*scale}px`;svg.style.height=`${selected.height*scale}px`;}
  function render(){
    const p=data.pages.find(p=>p.id===page),q=$('#search').value.trim().toLowerCase();
    $('#page-title').textContent=p.name;$('#page-subtitle').textContent=p.subtitle;$('#page-number').textContent=`PAGE ${String(data.pages.indexOf(p)+1).padStart(2,'0')} / SPRINGCAT`;$('#page-note').textContent=notes[page];$('#mobile-page').value=page;
    $('#download-sheet').href=`sheets/${String(data.pages.indexOf(p)+1).padStart(2,'0')}-${page}-${theme}.svg`;
    document.querySelectorAll('.page-button').forEach(b=>{b.classList.toggle('active',b.dataset.page===page);b.setAttribute('aria-current',b.dataset.page===page?'page':'false')});
    const all=data.boards.filter(a=>a.page===page),boards=all.filter(a=>(a.title+' '+a.id+' '+a.availability).toLowerCase().includes(q));
    $('#count').textContent=boards.length+' / '+all.length+' 块画板';$('#empty').hidden=boards.length>0;
    $('#boards').innerHTML=boards.map(a=>`<article class="artboard"><div class="artboard-title"><span>${escape(a.title)}</span><span class="id">${escape(a.id)}</span></div><button class="frame-button" data-id="${a.id}" aria-label="查看 ${escape(a.title)}">${a.svgs[theme]}</button><div class="artboard-meta">${meta(a)}<span>${a.width} × ${a.height}</span></div></article>`).join('');
    document.querySelectorAll('.frame-button').forEach(b=>{b.addEventListener('click',()=>select(b.dataset.id,matchMedia('(max-width:1150px)').matches));b.addEventListener('dblclick',()=>select(b.dataset.id,true));b.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();select(b.dataset.id,true)}})});
    if(boards.length)select(boards.some(a=>a.id===selected?.id)?selected.id:boards[0].id);
    $('#totals').textContent=`${data.boards.length} 块画板 · ${data.pages.length} 组页面 · 3 套主题 · ${data.boards.length*3} 个 SVG`;
  }
  function changePage(id){page=id;$('#search').value='';render();window.scrollTo({top:0,behavior:'instant'});history.replaceState(null,'','#'+page);}
  $('#pages').innerHTML=data.pages.map((p,i)=>`<button class="page-button" data-page="${p.id}"><span class="number">${String(i+1).padStart(2,'0')}</span>${escape(p.name)}<span class="pc">${data.boards.filter(a=>a.page===p.id).length}</span></button>`).join('');
  $('#mobile-page').innerHTML=data.pages.map(p=>`<option value="${p.id}">${escape(p.name)}</option>`).join('');
  document.querySelectorAll('.page-button').forEach(b=>b.addEventListener('click',()=>changePage(b.dataset.page)));
  $('#mobile-page').addEventListener('change',e=>changePage(e.target.value));$('#theme').addEventListener('change',e=>{theme=e.target.value;render();if($('#detail').open)openDetail()});$('#density').addEventListener('change',e=>$('#boards').dataset.density=e.target.value);$('#search').addEventListener('input',render);$('#clear-search').addEventListener('click',()=>{$('#search').value='';render()});$('#close-detail').addEventListener('click',()=>$('#detail').close());$('#detail-scale').addEventListener('change',scaleDetail);window.addEventListener('resize',scaleDetail);$('#detail').addEventListener('click',e=>{if(e.target===$('#detail'))$('#detail').close()});
  const hash=location.hash.slice(1);if(data.pages.some(p=>p.id===hash))page=hash;render();
})();
