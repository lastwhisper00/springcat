# Concept 06 · Unified

## Scope and authority

The user rejected the prominent waiting-task section in Concept 05. Pending confirmation is an ordinary task status, and several tasks can share it. This refinement replaces the split between a leading task and subordinate tasks with one uniform list. It preserves the professional desktop visual direction, three neutral themes, SpringCat name, small resting forms, docking positions, and 520px expanded width. The production Svelte/Tauri implementation is outside this change.

## Task list contract

1. Use the neutral heading “最近任务” and a quiet total count.
2. Every task has the same source-logo position, title size and weight, source/time line, row height, and background. The right edge shows a 12px state label and a 4px colored dot.
3. “待确认”, “进行中”, “已完成” and “失败” are peer statuses. Pending confirmation never creates a larger card, banner or separate action area.
4. Each pending task occupies one row. The default five-task example contains three waiting tasks interleaved with a running task and a completed task.
5. Sort by recent update when opening or refreshing. While reading, update a task in place and preserve its position, current page, and focused element.
6. Show at most five tasks per page, with explicit previous/next controls and total/range when more exist. Reducing page size on low-height native screens is an integration requirement, not behavior already implemented by this browser prototype. “全部任务” opens the full workspace.
7. Clicking a row opens that task’s existing detail. Request explanation and source actions belong in this detail. Reading or marking a task as read does not resolve a waiting status.

## Visual decisions

- Brand and three navigation choices keep the quiet header row.
- The list heading uses quiet 13px / 500 text and all task titles use 14px / 450; source, time, count, and state use 12px / 400. Detail titles use 20px / 550.
- All task rows are 64px high; longer content and narrow layouts must preserve readable text and accessible detail access.
- Row status text uses the same quiet text color; only the small state indicator varies by status.
- There are no per-row action buttons, nested cards, strong separators, or special completed-title dimming.
- “标记已读” remains a secondary text control. Source logos and existing lightweight SVG action icons are reused.
- Unpaginated panels follow their content height (470px for five tasks). Paginated lists preserve a 320px minimum list height, keeping both pages at 506px total height. There is no nested scrolling. Existing themes and motion rules remain unchanged.

## Skill application

Impeccable's Operate and Craft Floor rules support consistent controls, quiet semantic color, and predictable scanning. The existing design context permits scoped refinement without a new product interview. Karpathy Guidelines keep the change limited to the task list, its data examples, and the corresponding design artifacts. No new framework or runtime dependency is required.

## Verification record

The prototype inspection verified equal 64px rows, 14px / 450 task titles, and three waiting tasks remaining waiting after marking read. A specific task on page two opens its own detail; returning restores the same page and row focus. At a 390px viewport, the panel measures 323px wide with no inner-content overflow.

The mechanical detector ran once and reported only the existing decorative editor backdrop's small, low-contrast text and the shell width/height transition. This backdrop is hidden from assistive technology. Browser shell morphing is a prototype choice, not evidence of native compositor performance. After regeneration, all 288 SVG files passed XML parsing, all three JSON files parsed, and the prototype and viewer scripts passed syntax checks. The prototype console had no errors during the interaction checks.

## Integration limits

These are design prototypes. Real native-window motion, screen-edge constraints, safe areas, reduced-height page sizing, and cross-tool deep links require verification in Tauri. SVG artboards show static states; the prototype provides interaction examples. Reading a preview never grants approval to a source tool.
